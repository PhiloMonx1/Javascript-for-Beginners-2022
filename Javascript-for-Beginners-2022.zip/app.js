const title = document.querySelector("div.hello:first-child h1")

function handleTitleClick(){
    alert("ㅂㅅ 새끼 ㅋㅋㅋ")
}

title.addEventListener("click", handleTitleClick);

